Students:
Rida Zabad 	1278354
Jai Reddy 	1235883

Assignment Pattern Searching:
Java files REcompile.java & REsearch.java

Notes on REsearch.java the general command line follows cat ---.txt | java REsearch ---.txt
Note that the program will not read a file that has an empty line as its final line as it force an array out of bounds
Documentation has specified what code means on each line

Notes on REcompile Everything in the program works well but it does not handle the ![ ]!

Both programs agree to use the "~" as branching statement and the "." as wildcard literal.
